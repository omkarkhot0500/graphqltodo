import React from "react";
import "./App.css";
import { GET_TODOS } from "./graphql/Query";
import { useQuery } from "@apollo/client";
import AddTodos from "./components/AddTodos";
import Todo from "./components/Todo";
function App() {
  const { loading, error, data } = useQuery(GET_TODOS);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error.message}</p>;

  

  return (
    <div className="App min-h-screen flex items-center justify-center bg-gradient-to-r from-gray-800 to-black">
      <div className="max-w-md w-full p-5 border rounded shadow-lg bg-white bg-opacity-80">
        <h1 className="text-2xl font-bold mb-4 text-center text-gray-800">
          To-Do List
        </h1>
        <AddTodos/>
        <ul className="list-disc pl-5">
          {data?.getTodos.map((todo) => (
            <Todo
            id={todo.id}
            title={todo.title}
            detail={todo.detail}
            date={todo.date}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;

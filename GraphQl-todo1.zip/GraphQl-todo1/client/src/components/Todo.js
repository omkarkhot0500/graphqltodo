import React from "react";
import moment from 'moment'
import { useMutation } from "@apollo/client";
import { DELELTE_TODO } from "../graphql/Mutation";
import { GET_TODOS } from "../graphql/Query";


const Todo = ({id,title,detail,date}) => {
  const [deleteTodo] = useMutation(DELELTE_TODO);
  const handleDelete = (id) => {
      deleteTodo({
        variables:{
          id:id
        },refetchQueries:[
          {query:GET_TODOS}
        ]
      })
    };
  
  return (
    <li
      key={id}
      className="flex justify-between items-center mb-4 p-2 border-b"
    >
      <div>
        <h5 className="font-bold">{title}</h5>
        <p>{detail}</p>
      </div>
      <div className="flex flex-col items-end">
        <small className="text-gray-500">
          {moment(date).format("MMMM DD YYYY")}
        </small>
        <button
          onClick={() => handleDelete(id)}
          className="mt-2 bg-red-500 text-white rounded p-1 hover:bg-red-600 transition"
        >
          Delete
        </button>
      </div>
    </li>
  );
};

export default Todo;

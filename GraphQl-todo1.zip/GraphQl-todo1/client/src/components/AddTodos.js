import React, { useState } from "react";
import { useMutation } from "@apollo/client";
import { ADD_TODO } from "../graphql/Mutation";
import { GET_TODOS } from "../graphql/Query";
import moment from "moment";

const AddTodos = () => {
  const [todo, setTodo] = useState({
    title: "",
    detail: "",
    date: "",
  });

  const [addTodo] = useMutation(ADD_TODO);
  const onSubmit = (e) => {
    e.preventDefault();
    addTodo({
      variables: {
        title: todo.title,
        detail: todo.detail,
        date: todo.date,
      },
      refetchQueries: [{ query: GET_TODOS }],
    });
  };
  return (
    <form className="mb-4" onSubmit={onSubmit}>
      <input
        type="text"
        className="w-full border border-gray-300 rounded p-2 mb-4"
        placeholder="Title"
        value={todo.title}
        onChange={(e) => setTodo({ ...todo, title: e.target.value })}
      />
      <textarea
        className="w-full border border-gray-300 rounded p-2 mb-4"
        placeholder="Detail"
        value={todo.detail}
        onChange={(e) => setTodo({ ...todo, detail: e.target.value })}
      />
      <input
        type="date"
        className="w-full border border-gray-300 rounded p-2 mb-4"
        value={todo.date ? moment(todo.date).format("YYYY-MM-DD") : ""}
        onChange={(e) => setTodo({ ...todo, date: e.target.value })}
      />
      <button
        type="submit"
        className="bg-blue-500 text-white rounded p-2 w-full hover:bg-blue-600 transition"
      >
        Submit
      </button>
    </form>
  );
};

export default AddTodos;
